# iPhoneだけでGitHub Actionsを使ってビルドする

## 重要
- この設定はGitHub ActionsのmacOSランナーでXcodeプロジェクトを生成し、シミュレーター用とiPhone実機用のコンパイルを試します。
- 成果物は**署名なし**です。ZIPをダウンロードしただけではiPhoneへインストールできません。
- 実機に入れるにはAppleの署名・プロビジョニングが別途必要です。Apple Developer Programへの加入や有料配布はこの手順に含みません。
- 無料実行を優先する場合は公開リポジトリを使います。公開するとソースコードがインターネット上で誰でも見られます。個人情報、パスワード、APIキー、秘密のURLは絶対に含めないでください。公開に抵抗がある場合は、保護者と相談して非公開リポジトリの無料枠・利用量を確認してください。
- GitHubの標準macOSランナーは公開リポジトリで無料です。非公開リポジトリはアカウントの無料利用枠を消費し、超過時に課金対象になる場合があります。

## GitHubでの手順
1. GitHubアカウントにサインインし、新しいリポジトリを作ります。
2. 無料実行を使う場合は **Public** を選択します。ソースコードが公開されることを理解したうえで選んでください。
3. このZIPを展開し、`NekoAlarm_iOS_Starter` の中身をリポジトリのルートへアップロードします。`.github/workflows/ios-build.yml` と `project.yml` も含めます。
4. `main` ブランチへコミットすると、Actionsのビルドが自動で始まります。手動なら **Actions → Build NekoAlarm for iOS → Run workflow** です。
5. 成功したら実行結果の **Artifacts** から `NekoAlarm-unsigned-device-build` をダウンロードできます。

## まだ必要な作業
- Appleの署名を設定していないため、成果物はそのままiPhoneへインストールできません。
- AI音源サーバーの実装・接続先はまだありません。`NEKO_AI_AUDIO_ENDPOINT` は空です。公開リポジトリにAPIキーを直接書かないでください。
- GitHub Actions上のビルドが成功するかは、最初の実行で確認します。ここではXcodeコンパイルを実行していません。
