# 猫ミーム地獄アラーム — iOS 26+ SwiftUI starter

これはMacのXcode 26以降で開くためのSwiftソース一式です。署名済みアプリやIPAではありません。実機ビルド・テストはまだ行っていません。

## 実装している流れ
1. アプリ起動時に今日の日付のAI曲があるか確認。
2. なければAI音源サーバーへPOSTし、今日の日付をseedにしたオリジナルMP3を取得。
3. MP3を端末のApplication Supportへ保存。
4. アラーム予約時に `Library/Sounds` へコピーし、AlarmKitの `AlertSound.named` で指定。
5. アプリが午前0時をまたいで前面にある場合は日付変更を検知して生成。
6. iOSのバックグラウンド処理でも翌日0:05以降の生成を試す。生成通知は出さない。

## iOSの時間制約
`BGProcessingTask` はiOSが実行タイミングを決めるため、0:00ちょうどの実行は保証されません。アプリを強制終了している場合も、生成は次にOSがバックグラウンド処理を許可した時か、アプリを開いた時になります。Appleの説明：<https://developer.apple.com/documentation/uikit/using-background-tasks-to-update-your-app>

## AIサーバー
アプリには音楽生成サービスのAPIキーを入れません。`Backend/README_AI音源サーバー.md` の契約に合わせて、あなたが管理するHTTPSサーバーを用意してください。AIサービスが未指定のため、サービス固有のサーバー実装は含みません。

サーバーは `POST /generate` を受け、`Content-Type: audio/mpeg` でMP3バイナリを返します。アプリターゲットのInfoに `NEKO_AI_AUDIO_ENDPOINT`（String）としてURLを設定してください。

## Xcode設定
1. Xcode 26以降で iOS App / SwiftUI プロジェクトを新規作成（Deployment Target iOS 26.0）。
2. `App/` 内のSwiftファイル4つと `Shared/NekoAlarmMetadata.swift` をアプリターゲットへ追加。
3. `NSAlarmKitUsageDescription` をInfoに追加。
4. `NEKO_AI_AUDIO_ENDPOINT` をInfoに追加。
5. `BGTaskSchedulerPermittedIdentifiers` 配列に `jp.example.NekoAlarm.dailyTrackRefresh` を追加。
6. Signing & Capabilities > Background Modes で Background Processing を有効化。
7. Widget Extensionを作成し、`WidgetExtension/NekoAlarmLiveActivity.swift` と `Shared/NekoAlarmMetadata.swift` をWidgetターゲットにも追加。
8. `NSSupportsLiveActivities` = YES を設定。
9. Signing & CapabilitiesでTeamを選び、実機へビルド。

## 現在の仕様・制約
- AlarmKitはロック画面・Dynamic IslandにアラームUIを出し、カスタムサウンドを指定できます。音源ファイルはアプリのメインバンドルか `Library/Sounds` に置く必要があります。Apple WWDC資料：<https://developer.apple.com/videos/play/wwdc2025/230/>
- AI生成曲はAlarmKitの音源に接続するコードを追加済みですが、実際の音源再生はXcode SDKでのコンパイルとiPhone実機テストが必要です。
- iOSの標準停止操作をアプリ内クイズで完全に無効化することはできません。
- iPhone全体の音量をアプリが勝手に最大化することはできません。
- ロック画面で猫の独自アニメーションを動かし続けることはできません。
