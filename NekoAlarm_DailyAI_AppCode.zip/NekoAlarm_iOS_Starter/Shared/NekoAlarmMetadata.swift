import AlarmKit

struct NekoAlarmMetadata: AlarmMetadata, Codable {
    // Live Activityに渡す追加データはここに追加できます。
}
