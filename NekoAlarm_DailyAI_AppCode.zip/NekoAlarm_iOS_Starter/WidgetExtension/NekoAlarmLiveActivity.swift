import ActivityKit
import AlarmKit
import SwiftUI
import WidgetKit

struct NekoAlarmLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: AlarmAttributes<NekoAlarmMetadata>.self) { context in
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("🐱").font(.largeTitle)
                    VStack(alignment: .leading) {
                        Text("猫ミーム接近中").font(.headline)
                        Text("アラームまでカウントダウン")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "alarm.fill")
                        .font(.title2)
                }
                switch context.state.mode {
                case .countdown:
                    Text("起床準備をせよ…")
                        .font(.caption)
                case .paused:
                    Text("一時停止中")
                        .font(.caption)
                case .alert:
                    Text("猫ミーム警報発令！")
                        .font(.caption.bold())
                @unknown default:
                    Text("猫ミーム待機中")
                }
            }
            .padding()
            .activityBackgroundTint(Color.black)
            .activitySystemActionForegroundColor(Color.pink)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: "alarm.fill")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("🐱")
                }
                DynamicIslandExpandedRegion(.center) {
                    Text("猫ミーム地獄")
                        .font(.headline)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("起床準備をせよ…")
                        .font(.caption)
                }
            } compactLeading: {
                Image(systemName: "alarm.fill")
            } compactTrailing: {
                Text("🐱")
            } minimal: {
                Image(systemName: "alarm.fill")
            }
        }
    }
}

@main
struct NekoAlarmWidgetBundle: WidgetBundle {
    var body: some Widget {
        NekoAlarmLiveActivity()
    }
}
