# AI音源サーバーの接続仕様

APIキーをアプリに含めず、あなたの管理するHTTPSサーバーにAI音楽生成サービスを接続します。

## Request
`POST /generate`
```json
{
  "date": "2026-10-31",
  "prompt": "Create an original loud alarm instrumental...",
  "format": "mp3"
}
```

## Response
- Status: `200 OK`
- Header: `Content-Type: audio/mpeg`
- Body: raw MP3 bytes (8 KB以上)

`date` は日付単位の生成seedとして利用してください。同じ日付で何度リクエストされても同じ生成結果を返すようにサーバー側でキャッシュするのがおすすめです。別の日付ではジャンル・テンポ・音色・展開をランダム化してください。

アプリ側はレスポンスのMP3を保存し、AlarmKitのカスタムアラーム音として登録します。AIサービスごとにAPI形式が違うため、サービス固有の呼び出し処理は選定したサービスの仕様に合わせてサーバー側で実装してください。
