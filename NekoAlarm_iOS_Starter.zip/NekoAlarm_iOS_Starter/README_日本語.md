# 猫ミーム地獄アラーム（iPhone / SwiftUI）

これは iOS 26 以降向けの **Xcode用スターターソース** です。iPhoneにインストール済みの完成アプリや署名済みIPAではありません。MacのXcodeでビルドして、実機でAlarmKitの許可を与える必要があります。

## できること
- AlarmKitで指定時刻のアラームを予約
- アラーム前のカウントダウンをロック画面／Dynamic IslandのLive Activityに表示
- アプリ内にパスワード入力と3問クイズの解除画面
- 猫ミーム風の回転演出（アプリを開いている間）

## iOSの制約（重要）
- AlarmKitのアラーム画面には、iOSが管理する停止操作が表示されます。アプリ側のクイズを必須にして、iOSの停止操作を完全に封じることはできません。
- アラームが鳴っている間、アプリが終了・バックグラウンドの状態でも独自の猫アニメーションを動かし続けることはできません。ロック画面にはAlarmKitのシステム表示と、カウントダウン中のLive Activityが表示されます。
- アプリからiPhone全体の音量を時間経過で上げることはできません。AlarmKitの音はiOSが管理します。段階的な音量演出は、アプリを前面表示している間の追加機能としてのみ実装可能です。
- このサンプルのパスワードは端末内にSHA-256ハッシュで保存します。忘れた場合はアプリ内で再設定する設計に拡張してください。

## Xcodeでのセットアップ
1. Macに Xcode 26 以降を用意します。
2. `File > New > Project > iOS > App` で `NekoAlarm` というSwiftUIアプリを作成します。
3. Deployment Targetを **iOS 26.0** にします。
4. `App/` 内の3つのSwiftファイルと `Shared/NekoAlarmMetadata.swift` をアプリターゲットに追加します。
5. `Info.plist` に次のキーを追加します：
   - Key: `NSAlarmKitUsageDescription`
   - Value: `猫ミーム地獄アラームの予約とロック画面表示に使用します。`
6. Live Activity表示も追加する場合：
   - `File > New > Target > Widget Extension` でWidget Extensionを追加します。
   - `WidgetExtension/NekoAlarmLiveActivity.swift` と `Shared/NekoAlarmMetadata.swift` をWidget Extensionターゲットにも追加します（同じ共有ファイルを両ターゲットに含めます）。
   - Widget ExtensionのDeployment TargetもiOS 26.0にします。
   - アプリの `Info.plist` に `NSSupportsLiveActivities` = `YES` を追加します。
7. Signing & Capabilitiesで自分のApple開発チームを選択し、Bundle Identifierを設定します。
8. iPhoneを接続して実機ビルドします。AlarmKitの許可ダイアログが出たら許可してください。

## 収録ファイル
- `App/NekoAlarmApp.swift` — アプリ起動
- `App/ContentView.swift` — アラーム設定、パスワード、クイズ画面
- `App/AlarmScheduler.swift` — AlarmKitで時刻予約
- `WidgetExtension/NekoAlarmLiveActivity.swift` — ロック画面／Dynamic Islandのカウントダウン表示
- `Shared/NekoAlarmMetadata.swift` — アプリとWidget Extensionで共有するAlarmKitメタデータ

## 注意
このスターターはXcodeでの最終ビルド・実機テストを行っていません。iOS SDKの更新によりAPIの微調整が必要になる場合があります。Apple公式のAlarmKitドキュメントも確認してください：
https://developer.apple.com/documentation/alarmkit
